/** Automatically generated file. DO NOT MODIFY */
package com.juns.wechat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}