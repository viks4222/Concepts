package com.juns.wechat.widght.swipe.interfaces;

public interface SwipeAdapterInterface {
	public int getSwipeLayoutResourceId(int position);
}
