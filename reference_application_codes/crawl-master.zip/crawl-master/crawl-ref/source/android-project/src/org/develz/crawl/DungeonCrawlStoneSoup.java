package org.develz.crawl;

import org.libsdl.app.SDLActivity;

/*
 * A sample wrapper class that just calls SDLActivity
 */

public class DungeonCrawlStoneSoup extends SDLActivity { }
