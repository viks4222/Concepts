#ifndef CTEST_H
#define CTEST_H

#ifdef DEBUG_TESTS
NORETURN void run_tests();
#endif

#endif
