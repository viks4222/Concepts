This directory contains scripts that are used by hooks running
on crawl.develz.org. They are here rather than in CDO's .git/hooks/
directory so that they can be edited by all developers.
